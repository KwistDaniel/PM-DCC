# Lote con 2 errores #
# el ] post b y el >== #

void main(){

    int a,b],c;
    if (a >== c){
        a=0;
    }
}
# Linea comentario #