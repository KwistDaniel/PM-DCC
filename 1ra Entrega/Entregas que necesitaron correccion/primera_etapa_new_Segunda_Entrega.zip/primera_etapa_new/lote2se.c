void f1(){
    int a;
    a=10;
}

# Linea comentario #

void fmain(){
    cout << "Hola mundo";
}

# Linea comentario #