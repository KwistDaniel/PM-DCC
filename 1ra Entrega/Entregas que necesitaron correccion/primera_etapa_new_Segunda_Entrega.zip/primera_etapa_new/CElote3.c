# Lote con varios errores #
# falta tipo de b linea 8 #
# falta ) del return en rama else linea 13 #
# simbolo inesperado despues de la coma en linea 21 #
# falta << y simbolo inesperado linea 23 #
# falta simbolo despues de >> linea 25 #

void f1(int a, b){
    if (a>b){
        return (a+b);
    }
    else{
        return (2**b;
    }

}


void main(){

    f1(ab,);

    cout < "hola";

    cin >> a >> ;

}
# Linea comentario #