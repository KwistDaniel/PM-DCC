int a;
int b,c;

void f1(){
    int a;
    a=10;
}

void f2(){
    a=10;
    int b;
    int c;
}

void f1(){
    a=100;
    b=1010;
    c=101010;
    int d;
}

void noMeDejaVolverADeclararVariablesConMismoNombre(){
    int x;
}

void pareceQueSeComeTodaLaSiguienteLineaDeCodigo(){
    int y;
}