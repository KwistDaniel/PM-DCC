int a;
int b,c;

void f1(){
    c=100;
}