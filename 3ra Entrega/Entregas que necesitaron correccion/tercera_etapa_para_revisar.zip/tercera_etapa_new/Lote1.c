# Parte 2 #
# Errores: #
# Definicion de variables simples y arreglos tipo void #
# Definicion e inicializacion incorrecta de arreglos #
# Asignaciones incorrectas #
# Acceso incorrecto a arreglos #

void main(){
    int a;
    a = 2;
    cout << a;
    cout << "hola";
}

# Linea comentario #