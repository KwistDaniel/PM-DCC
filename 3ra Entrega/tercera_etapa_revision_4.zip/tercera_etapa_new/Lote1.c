# Generacion de codigo #


void main(){
    int b;
    int a = 1;
    int c = 20;
    if(a == 2){
        a = 3;
    }
    else{
        a = 5;
    }
    cout << "Prueba";
    cout << "De";
    cout << "String";
    cout << (a+b) << c;
    if(1){
        cout << "IF";
    }
    else{
        cout << "ELSE";
    }
    if (1)
    cout << "IF2";
    else cout << "ELSE2";
}

# Linea comentario #