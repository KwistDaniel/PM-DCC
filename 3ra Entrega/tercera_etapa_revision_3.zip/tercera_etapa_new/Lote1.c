# Generacion de codigo #


void main(){
    int a = 1;
    if(a == 2){
        a = 3;
    }
    else{
        a = 5;
    }
    cout << "Prueba";
    cout << "De";
    cout << "String";
    cout << a;
}

# Linea comentario #