# Parte 2 #
# Control de iteracion y seleccion #

void f1(){
}

void main(){
    int a[1];
    if(a){}
    while(a){}
    if(a[1]){}
    while(a[1]){}
    if(f1()){}
    while(f1()){}
}

# Linea comentario #