# Parte 2 #
# Funcion main definida mas de una vez, con argumentos y tipo distinto a void #

void main(){

}

int main(int a, char b){

}

# Linea comentario #