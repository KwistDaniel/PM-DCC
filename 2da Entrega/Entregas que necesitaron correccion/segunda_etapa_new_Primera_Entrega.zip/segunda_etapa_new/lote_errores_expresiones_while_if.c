int indice;
int a[]={1,2,3};

int fsuma(int a,int b){
  return a+b;
}
int main() {
  indice = 0;

  while <=2) {  #falta ( y operando de while#
    a[indice]=fsuma(a[indice],1);
    indice=indice+1;

  }
  if a[0] 2){ #falta ( y operador de if #
    indice=0;
  }else indice=2;
  return 0;
  if (i<){ #falta operando #
    int f;
  }

}
