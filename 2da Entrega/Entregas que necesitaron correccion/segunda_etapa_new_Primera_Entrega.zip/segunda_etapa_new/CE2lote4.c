# Parte 2 #
# Variable ya definida #
# Arreglo, variable y parametro tipo void #
# Regla 10 #

int b;

void aux(void z){
    int a,d;
    int a;
    int b[1],c[1];
    int e[1],f[1];
    void x;
    void y[];
    d = 'a';
    b[1] = c;
    e = f;
}

void main(){
    aux(b);
}

# Linea comentario #