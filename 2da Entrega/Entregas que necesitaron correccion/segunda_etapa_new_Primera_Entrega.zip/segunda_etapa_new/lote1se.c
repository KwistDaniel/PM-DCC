int a;
int b,c;

void f1(){
    int a;
    a=10;
    c=100;
}