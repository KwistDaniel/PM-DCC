# Parte 2 #
# Control de I/O #

void main(){
    int a;
    int c[2];
    cin >> b;
    cin >> a;
    cin >> c[1];
    cin >> c;
    cout << "hola";
    cout << c[1] << "De nuevo";
}

# Linea comentario #