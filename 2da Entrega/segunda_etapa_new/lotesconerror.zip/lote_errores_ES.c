void main(){


int variable;

cout << "Introduzca un numero: " ; 

cin >> var; 

cout << "\n\n El numero escrito es: " << var;

cout << a < endl; #No se encontro error, ya que entra por Constante < Variable #

cin >> var; #Error de <<#

cout << ; #Error#

cit<<a;#Simbolo inesperado en lugar de cin#

cout<<;#No se encuentra error ya que toma endl como constante# 


}
