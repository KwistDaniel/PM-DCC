# Lote con 1 error #
# Falta el cout #

void fmain(){
    << "Hola mundo";
}

# Linea comentario #