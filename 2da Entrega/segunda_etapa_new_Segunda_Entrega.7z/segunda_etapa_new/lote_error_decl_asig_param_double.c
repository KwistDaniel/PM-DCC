double fcrash ( int, float a, b, int){ #parametros incorrectos#
  int x;
  x= d+c;
  return ; #falta valor de retorno#
}
