double fcrash ( int, float a, b, int){ #parametros incorrectos#
  int x;
  x= d+c;
  while( x<=1 ||x==9 ){
    if (! c){
      x=x+1;
    } else {
      x=x-1;
    }
  }
  return ; #falta valor de retorno#
}
int main(){
  int c[]=,2,3};#arreglo mal declarado#
  int a;
  float ; #falta identificador#
  a=8;
  if (a=2){
    a= ; #falta valor#
    a= "string";
    = x; #simbolo inesperado,falta variable#
    a =(3<1);
    a = fcrash);#falta (#
  }
}
