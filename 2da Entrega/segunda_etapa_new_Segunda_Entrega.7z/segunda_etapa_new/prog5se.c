
float var=1.333;

void main () {

   float e;

   var = 1 + 'a'+ 7.4545;

   cout << "var= " << var << "\n";

   if ( !(e = var) ) {
      var= var - 1;
   }
   cout << "var - 1= " << var << "\n";
   cout << "e= " << e << "\n";
   e= (1.7 + var)/2 ;
   cout << "1.7 + var / 2= " <<  e << "\n";

} 
