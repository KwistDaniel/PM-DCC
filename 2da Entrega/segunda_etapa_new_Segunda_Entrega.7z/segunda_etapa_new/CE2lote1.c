# Parte 2 #
# Errores: #
# Definicion de variables simples y arreglos tipo void #
# Definicion e inicializacion incorrecta de arreglos #
# Asignaciones incorrectas #
# Acceso incorrecto a arreglos #

void main(){
    void a;
    void b[1];
    int c[] = {1,2,'3'}, d[];
    char e[] = {'a','b',3};
    int f[2] = {1,2,3};
    int g[2] = {};
    int h[] = {1};
    char i = 'a';
    int j = '1';
    int k[0];
    int l['a'];
    int m,n,o;
    char p[7];
    m = c || 5;
    e[0] = 1;
    c[1] = 1;
    p[1] = h;
}

# Linea comentario #