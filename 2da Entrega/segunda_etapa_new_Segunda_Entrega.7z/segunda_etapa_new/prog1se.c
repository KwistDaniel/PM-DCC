
void main() {

int i=0, leer;

cout << "Ingrese un numero cualquiera: ";
cin >> leer;

cout << "\n\n Los digitos son los siguientes";

while (i < 10) {
   cout << "El numero es: " << i;
   i= i+1;   
}
 
}
